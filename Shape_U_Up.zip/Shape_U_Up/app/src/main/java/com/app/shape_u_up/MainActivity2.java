package com.app.shape_u_up;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.EditText;
import android.widget.Toast;




public class MainActivity2 extends AppCompatActivity {

   EditText dateformat,gen,hei,wei;
      Button button1;
  Dbhandler g;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
//
//        g = new Dbhandler(this);
//     //  SQLiteDatabase db = g.getReadableDatabase();
//
//
//        gen=findViewById(R.id.gender);
//        hei=findViewById(R.id.height);
//        wei=findViewById(R.id.weight);
          button1=findViewById(R.id.loginbtn);

    //    dateformat =  findViewById(R.id.dateformatID);





        button1.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
//                Intent intent = getIntent();
//                String username = intent.getStringExtra(MainActivity.MSG);
//                String phonenumber = intent.getStringExtra(MainActivity.MSG1);
//                String age = dateformat.getText().toString();
//                String gen1 = gen.getText().toString();
//                String hei1 = hei.getText().toString();
//                String wei1 = wei.getText().toString();
                Intent inten = new Intent(MainActivity2.this, HomeOne.class);
                startActivity(inten);
//                if (username.equals(" ") || phonenumber.equals(" ") || age.equals("") ||  gen1.equals(" ") || hei1.equals(" ") || wei1.equals(" ")) {
//
//                    Toast.makeText(MainActivity2.this, "Enter all the fields", Toast.LENGTH_SHORT).show();
//                }
//                else {
//                    boolean i = g.insert_data(username, phonenumber, age, gen1, hei1, wei1);
//                    if (i) {
//                        Toast.makeText(MainActivity2.this, "Successfully inserted", Toast.LENGTH_SHORT).show();
//                    } else {
//                        Toast.makeText(MainActivity2.this, "Couldn't Insert ", Toast.LENGTH_SHORT).show();
//                    }


                }


        });













    }
}