package com.app.shape_u_up;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_home_one);
        Button button = findViewById (R.id.button);
        Button button2 = findViewById (R.id.button2);
        Button button3 = findViewById (R.id.button3);

        button.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent inten = new Intent (HomeOne.this,MainActivity4.class);
                startActivity (inten);
            }
        });
        button2.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent inten1 =new Intent (HomeOne.this,MainActivity5.class);
                startActivity (inten1);
            }
        });
        button3.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent inten2=new Intent (HomeOne.this,MainActivity3.class);
                startActivity (inten2);
            }
        });
    }
}