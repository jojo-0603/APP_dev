package com.app.shape_u_up;

import android.app.Notification;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;


public class MainActivity3 extends AppCompatActivity {

    private NotificationManagerCompat notificationManagerCompat;

    private EditText editTextTitle;
    private EditText editTextMessage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main3);

        this.editTextTitle = this.findViewById (R.id.editText_title);
        this.editTextMessage = this.findViewById (R.id.editText_message);

        Button button1 = this.findViewById (R.id.button1);
        Button button2 = this.findViewById (R.id.button2);

        button1.setOnClickListener (new View.OnClickListener () {

            @Override
            public void onClick(View view) {
                sendOnChannel1 ();
            }
        });

        button2.setOnClickListener (new View.OnClickListener () {

            @Override
            public void onClick(View view) {
                sendOnChannel2 ();
            }
        });

        //
        this.notificationManagerCompat = NotificationManagerCompat.from (this);
    }


    private void sendOnChannel1() {
        String title = this.editTextTitle.getText ().toString ();
        String message = this.editTextMessage.getText ().toString ();

        Notification notification = new NotificationCompat.Builder (this, NotifyMe.CHANNEL_1_ID)
                .setSmallIcon (R.drawable.ic_launcher_foreground)
                .setContentTitle (title)
                .setContentText (message)
                .setPriority (NotificationCompat.PRIORITY_HIGH)
                .setCategory (NotificationCompat.CATEGORY_MESSAGE)
                .build ();

        int notificationId = 1;
        if (ActivityCompat.checkSelfPermission (this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        this.notificationManagerCompat.notify (notificationId, notification);
    }

    private void sendOnChannel2() {
        String title = this.editTextTitle.getText ().toString ();
        String message = this.editTextMessage.getText ().toString ();

        Notification notification = new NotificationCompat.Builder (this, NotifyMe.CHANNEL_2_ID)
                .setSmallIcon (R.drawable.ic_launcher_background)
                .setContentTitle (title)
                .setContentText (message)
                .setPriority (NotificationCompat.PRIORITY_LOW)
                .setCategory (NotificationCompat.CATEGORY_PROMO) // Promotion.
                .build ();

        int notificationId = 2;
        if (ActivityCompat.checkSelfPermission (this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        this.notificationManagerCompat.notify (notificationId, notification);
    }
}