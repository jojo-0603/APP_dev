package com.app.shape_u_up;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class Dbhandler extends SQLiteOpenHelper {
    private static final String DB_Name ="Sign_Up";
    public Dbhandler( Context context) {
        super(context, DB_Name, null, 2);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String q =  "CREATE TABLE user1(Username TEXT  , PhoneNumber TEXT, Age TEXT , Gender TEXT , Height TEXT  ,Weight TEXT ) " ;
        db.execSQL(q);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       db.execSQL("DROP TABLE IF EXISTS user1 ");
        onCreate(db);
    }
    public boolean insert_data(String username  ,String phnum,String age ,String gender ,String height ,String weight )
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues c= new ContentValues();
        c.put("Username",username);

        c.put("Phonenumber  ",phnum);
        c.put("Age", age);
        c.put("Gender",gender);
        c.put("Height",height);
        c.put("Weight",weight);

        long r = db.insert("user1", null, c);
        if(r==-1){
            return false;
        }
        else
            return true;
    }
}
