package com.app.shape_u_up;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {
    LineChart lineChart;

    @Override
    protected void onCreate (Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);


        lineChart=(LineChart)findViewById(R.id.line_chart);

        ArrayList<Entry> information=new ArrayList<>();
        information.add(new Entry(1,35));
        information.add(new Entry(2,60));
        information.add(new Entry(3,30));
        information.add(new Entry(4,32));
        information.add(new Entry(5,40));
        information.add(new Entry(6,10));
        information.add(new Entry(7,20));
        information.add(new Entry(8,50));
        information.add(new Entry(9,75));

        lineChart.setBackgroundColor (Color.WHITE);
        lineChart.setDrawGridBackground (false);
        lineChart.setDrawBorders (true);
        lineChart.setBorderColor (Color.BLACK);
        lineChart.setBorderWidth (2);
        LineDataSet lineDataSet=new LineDataSet(information," ");
        lineDataSet.setLineWidth (5);
        lineDataSet.setColor (Color.BLACK);
        lineDataSet.setDrawCircles (true);
        lineDataSet.setDrawCircleHole (false);
        lineDataSet.setCircleColor (Color.BLACK);
        lineDataSet.setCircleRadius (5);


        LineData lineData=new LineData(lineDataSet);



        lineChart.setData(lineData);

}
}
