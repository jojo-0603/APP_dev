package com.app.shape_u_up;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public static final String MSG ="com.app.shape_u_up.MSG";
    public static final String MSG1 ="com.app.shape_u_up.MSG1";
    EditText name;
    EditText phnum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button2);
        name=findViewById(R.id.editTextTextPersonName);
        phnum=findViewById(R.id.editTextTextPersonName2);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                String nam = name.getText().toString();
                String pho_num = phnum.getText().toString();
                intent.putExtra(MSG,nam);
                intent.putExtra(MSG1,pho_num);

                startActivity(intent);
            }
        });

    }
}